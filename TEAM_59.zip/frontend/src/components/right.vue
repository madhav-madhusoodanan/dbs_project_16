<template>
    <svg
        class="h-9 w-9 text-green-400"
        focusable="false"
        aria-hidden="true"
        viewBox="0 0 24 24"
        data-testid="KeyboardArrowRightIcon"
        fill="currentColor"
    >
        <path d="M8.59 16.59 13.17 12 8.59 7.41 10 6l6 6-6 6-1.41-1.41z"></path>
    </svg>
</template>
