<template>
    <svg
        class="h-9 w-9 p-1"
        focusable="false"
        aria-hidden="true"
        viewBox="0 0 24 24"
        data-testid="CompareArrowsIcon"
        fill="currentColor"
    >
        <path
            d="M9.01 14H2v2h7.01v3L13 15l-3.99-4v3zm5.98-1v-3H22V8h-7.01V5L11 9l3.99 4z"
        ></path>
    </svg>
</template>
